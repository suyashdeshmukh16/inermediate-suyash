window["ga-disable-G-7R092VY3DE"] = true;
window.dataLayer = window.dataLayer || [];
function gtag() {
  dataLayer.push(arguments);
}
gtag("js", new Date());
gtag("config", "G-7R092VY3DE");
