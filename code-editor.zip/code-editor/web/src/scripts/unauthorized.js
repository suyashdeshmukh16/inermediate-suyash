const loginButton = document.querySelector("button.login");
import { login } from "./utils/common";

loginButton.addEventListener("click", login);
